---
id: "sch:util"
kind: schema
name: util
domains: []
relations: 0
functions: 7
workspace_fingerprint: "sha256:21358dd85521af1b5dcd2a27de02214d6d9202cf00158645f05332add0f5fa15"
---
# util

Shared helper functions. Owns no domain tables. Domains: —.

_None._

Functions: [`current_tenant_id`](../../functions/util/current_tenant_id.md), [`default_tenant_id`](../../functions/util/default_tenant_id.md), [`ensure_month_partitions`](../../functions/util/ensure_month_partitions.md), [`reject_mutation`](../../functions/util/reject_mutation.md), [`set_updated_at`](../../functions/util/set_updated_at.md), [`uuidv7`](../../functions/util/uuidv7.md), [`validate_predecessor`](../../functions/util/validate_predecessor.md).

Types: none.
