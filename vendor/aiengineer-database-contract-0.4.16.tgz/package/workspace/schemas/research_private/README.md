---
id: "sch:research_private"
kind: schema
name: research_private
domains: []
relations: 0
functions: 17
workspace_fingerprint: "sha256:21358dd85521af1b5dcd2a27de02214d6d9202cf00158645f05332add0f5fa15"
---
# research_private

Domains: —.

_None._

Functions: [`begin_research_session`](../../functions/research_private/begin_research_session.md), [`begin_synthesis_session`](../../functions/research_private/begin_synthesis_session.md), [`checkpoint_pre_research_stage_input`](../../functions/research_private/checkpoint_pre_research_stage_input.md), [`claim_pre_research_stage`](../../functions/research_private/claim_pre_research_stage.md), [`claim_pre_research_video`](../../functions/research_private/claim_pre_research_video.md), [`complete_pre_research_stage`](../../functions/research_private/complete_pre_research_stage.md), [`complete_research_phase`](../../functions/research_private/complete_research_phase.md), [`complete_synthesis_phase`](../../functions/research_private/complete_synthesis_phase.md), [`current_transcript_hash`](../../functions/research_private/current_transcript_hash.md), [`ensure_pre_research_stage_rows`](../../functions/research_private/ensure_pre_research_stage_rows.md), [`evaluate_pre_research_qualification`](../../functions/research_private/evaluate_pre_research_qualification.md), [`list_finished_pre_research_videos`](../../functions/research_private/list_finished_pre_research_videos.md), [`park_pre_research_stage`](../../functions/research_private/park_pre_research_stage.md), [`project_pre_research_video_state`](../../functions/research_private/project_pre_research_video_state.md), [`reconcile_pre_research_stage_rows`](../../functions/research_private/reconcile_pre_research_stage_rows.md), [`refresh_pre_research_video_qualification`](../../functions/research_private/refresh_pre_research_video_qualification.md), [`touch_pre_research_run`](../../functions/research_private/touch_pre_research_run.md).

Types: none.
