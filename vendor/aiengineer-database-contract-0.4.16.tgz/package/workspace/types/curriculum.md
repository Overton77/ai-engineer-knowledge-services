---
id: "types:curriculum"
kind: types
schema: curriculum
enums: 1
domains: 0
composites: 0
workspace_fingerprint: "sha256:21358dd85521af1b5dcd2a27de02214d6d9202cf00158645f05332add0f5fa15"
---
# Types in curriculum

## Enums
| Enum | Labels | TypeScript |
| --- | --- | --- |
| `publish_status` | `draft`, `in_review`, `published`, `retired` | `Database["curriculum"]["Enums"]["publish_status"]` |
