---
id: "types:knowledge"
kind: types
schema: knowledge
enums: 2
domains: 0
composites: 0
workspace_fingerprint: "sha256:21358dd85521af1b5dcd2a27de02214d6d9202cf00158645f05332add0f5fa15"
---
# Types in knowledge

## Enums
| Enum | Labels | TypeScript |
| --- | --- | --- |
| `maturity` | `experimental`, `emerging`, `established`, `declining` | `Database["knowledge"]["Enums"]["maturity"]` |
| `revalidation_state` | `fresh`, `due`, `in_progress`, `stale`, `failed`, `retired` | `Database["knowledge"]["Enums"]["revalidation_state"]` |
