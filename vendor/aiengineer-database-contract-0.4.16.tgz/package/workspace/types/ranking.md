---
id: "types:ranking"
kind: types
schema: ranking
enums: 1
domains: 0
composites: 0
workspace_fingerprint: "sha256:21358dd85521af1b5dcd2a27de02214d6d9202cf00158645f05332add0f5fa15"
---
# Types in ranking

## Enums
| Enum | Labels | TypeScript |
| --- | --- | --- |
| `approval_state` | `draft`, `proposed`, `approved`, `deprecated`, `rejected` | `Database["ranking"]["Enums"]["approval_state"]` |
