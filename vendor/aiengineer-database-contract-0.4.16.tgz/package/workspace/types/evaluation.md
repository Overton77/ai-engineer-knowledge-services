---
id: "types:evaluation"
kind: types
schema: evaluation
enums: 2
domains: 0
composites: 0
workspace_fingerprint: "sha256:21358dd85521af1b5dcd2a27de02214d6d9202cf00158645f05332add0f5fa15"
---
# Types in evaluation

## Enums
| Enum | Labels | TypeScript |
| --- | --- | --- |
| `gate_action` | `block`, `quarantine`, `repair`, `rerun`, `review`, `escalate`, `optimize`, `allow` | `Database["evaluation"]["Enums"]["gate_action"]` |
| `review_state` | `open`, `claimed`, `in_review`, `decided`, `escalated`, `cancelled` | `Database["evaluation"]["Enums"]["review_state"]` |
