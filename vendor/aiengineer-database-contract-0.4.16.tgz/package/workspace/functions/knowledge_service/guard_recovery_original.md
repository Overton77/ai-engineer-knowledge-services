---
id: "fn:knowledge_service.guard_recovery_original()"
kind: function
schema: knowledge_service
name: guard_recovery_original
domain: knowledge-service-runtime
overloads: ["fn:knowledge_service.guard_recovery_original()"]
security: invoker
volatility: volatile
executors: []
raises: [recovery original counters cannot reset]
touches: { reads: [], writes: [] }
tokens: [knowledge_service, guard_recovery_original, knowledge_service.guard_recovery_original]
defined_in: ["20260914010700_durable_verification_recovery.sql", "20260916020000_recovery_original_authority.sql"]
workspace_fingerprint: "sha256:21358dd85521af1b5dcd2a27de02214d6d9202cf00158645f05332add0f5fa15"
---
# knowledge_service.guard_recovery_original

Domain `knowledge-service-runtime`.

## guard_recovery_original() → trigger

function, volatile, security invoker, language plpgsql, config `search_path=""`.

No arguments.

Execute: no configured role.

Raises (mechanically extracted): `recovery original counters cannot reset`.

Defined in: `20260914010700_durable_verification_recovery.sql`, `20260916020000_recovery_original_authority.sql`.
