---
id: "fn:knowledge_service.guard_recovery_execution()"
kind: function
schema: knowledge_service
name: guard_recovery_execution
domain: knowledge-service-runtime
overloads: ["fn:knowledge_service.guard_recovery_execution()"]
security: invoker
volatility: volatile
executors: []
raises: [recovery execution authorization is immutable]
touches: { reads: [], writes: [] }
tokens: [knowledge_service, guard_recovery_execution, knowledge_service.guard_recovery_execution]
defined_in: ["20260914010700_durable_verification_recovery.sql"]
workspace_fingerprint: "sha256:21358dd85521af1b5dcd2a27de02214d6d9202cf00158645f05332add0f5fa15"
---
# knowledge_service.guard_recovery_execution

Domain `knowledge-service-runtime`.

## guard_recovery_execution() → trigger

function, volatile, security invoker, language plpgsql, config `search_path=""`.

No arguments.

Execute: no configured role.

Raises (mechanically extracted): `recovery execution authorization is immutable`.

Defined in: `20260914010700_durable_verification_recovery.sql`.
