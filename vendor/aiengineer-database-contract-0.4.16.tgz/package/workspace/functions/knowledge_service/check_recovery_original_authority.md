---
id: "fn:knowledge_service.check_recovery_original_authority()"
kind: function
schema: knowledge_service
name: check_recovery_original_authority
domain: knowledge-service-runtime
overloads: ["fn:knowledge_service.check_recovery_original_authority()"]
security: invoker
volatility: volatile
executors: [anon, app_reader, authenticated, control_plane, executor_service, pipeline_agent, service_role, verifier_agent]
raises: [recovery original binding already belongs to another case, recovery original requires a tenant-scoped verification intent, recovery original requires exactly one authority]
touches: { reads: [orchestration.operation_intent], writes: [knowledge_service.recovery_binding_owner] }
tokens: [knowledge_service, check_recovery_original_authority, knowledge_service.check_recovery_original_authority]
defined_in: ["20260916020000_recovery_original_authority.sql", "20260916020100_recovery_binding_ownership.sql", "20260916020200_recovery_owner_lookup.sql"]
workspace_fingerprint: "sha256:21358dd85521af1b5dcd2a27de02214d6d9202cf00158645f05332add0f5fa15"
---
# knowledge_service.check_recovery_original_authority

Domain `knowledge-service-runtime`.

## check_recovery_original_authority() → trigger

function, volatile, security invoker, language plpgsql, config `search_path=""`.

No arguments.

Execute: `anon`, `app_reader`, `authenticated`, `control_plane`, `executor_service`, `pipeline_agent`, `service_role`, `verifier_agent`.

Raises (mechanically extracted): `recovery original binding already belongs to another case`; `recovery original requires a tenant-scoped verification intent`; `recovery original requires exactly one authority`.

Touches (best effort): reads [`orchestration.operation_intent`](../../relations/orchestration/operation_intent.md); writes [`knowledge_service.recovery_binding_owner`](../../relations/knowledge_service/recovery_binding_owner.md); calls —.

Defined in: `20260916020000_recovery_original_authority.sql`, `20260916020100_recovery_binding_ownership.sql`, `20260916020200_recovery_owner_lookup.sql`.
