---
id: "fn:knowledge_service.guard_recovery_case()"
kind: function
schema: knowledge_service
name: guard_recovery_case
domain: knowledge-service-runtime
overloads: ["fn:knowledge_service.guard_recovery_case()"]
security: invoker
volatility: volatile
executors: []
raises: [recovery original authority is immutable]
touches: { reads: [], writes: [] }
tokens: [knowledge_service, guard_recovery_case, knowledge_service.guard_recovery_case]
defined_in: ["20260914010700_durable_verification_recovery.sql"]
workspace_fingerprint: "sha256:21358dd85521af1b5dcd2a27de02214d6d9202cf00158645f05332add0f5fa15"
---
# knowledge_service.guard_recovery_case

Domain `knowledge-service-runtime`.

## guard_recovery_case() → trigger

function, volatile, security invoker, language plpgsql, config `search_path=""`.

No arguments.

Execute: no configured role.

Raises (mechanically extracted): `recovery original authority is immutable`.

Defined in: `20260914010700_durable_verification_recovery.sql`.
