---
id: "fn:knowledge_service.guard_recovery_revision_artifact()"
kind: function
schema: knowledge_service
name: guard_recovery_revision_artifact
domain: knowledge-service-runtime
overloads: ["fn:knowledge_service.guard_recovery_revision_artifact()"]
security: definer
volatility: volatile
executors: []
raises: [recovery revision requires exact available artifact]
touches: { reads: [orchestration.artifact], writes: [] }
tokens: [knowledge_service, guard_recovery_revision_artifact, knowledge_service.guard_recovery_revision_artifact]
defined_in: ["20260914010700_durable_verification_recovery.sql"]
workspace_fingerprint: "sha256:21358dd85521af1b5dcd2a27de02214d6d9202cf00158645f05332add0f5fa15"
---
# knowledge_service.guard_recovery_revision_artifact

Domain `knowledge-service-runtime`.

## guard_recovery_revision_artifact() → trigger

function, volatile, security definer, language plpgsql, config `search_path=""`.

No arguments.

Execute: no configured role.

Raises (mechanically extracted): `recovery revision requires exact available artifact`.

Touches (best effort): reads [`orchestration.artifact`](../../relations/orchestration/artifact.md); writes —; calls —.

Defined in: `20260914010700_durable_verification_recovery.sql`.
