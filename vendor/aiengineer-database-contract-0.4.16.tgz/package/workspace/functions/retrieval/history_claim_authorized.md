---
id: "fn:retrieval.history_claim_authorized(uuid)"
kind: function
schema: retrieval
name: history_claim_authorized
domain: retrieval
overloads: ["fn:retrieval.history_claim_authorized(uuid)"]
security: definer
volatility: stable
executors: []
raises: []
touches: { reads: [evidence.claim, evidence.claim_evidence_assessment, evidence.claim_evidence_link, evidence.locator, evidence.source_capture, evidence.verification_run, orchestration.artifact], writes: [] }
tokens: [retrieval, history_claim_authorized, retrieval.history_claim_authorized]
defined_in: ["20260914011100_retrieval_history.sql"]
workspace_fingerprint: "sha256:21358dd85521af1b5dcd2a27de02214d6d9202cf00158645f05332add0f5fa15"
---
# retrieval.history_claim_authorized

Domain `retrieval`.

## history_claim_authorized(uuid) → boolean

function, stable, security definer, language sql, config `search_path=""`. Current authorization of one canonical claim: verified or superseded status, succeeded sealed run, matching audit artifact bytes, and at least one resolved supporting locator with a replayable assessment.

| Argument | Type | Default | Mode |
| --- | --- | --- | --- |
| `p_claim` | `uuid` | — | — |

Execute: no configured role.

Touches (best effort): reads [`evidence.claim`](../../relations/evidence/claim.md), [`evidence.claim_evidence_assessment`](../../relations/evidence/claim_evidence_assessment.md), [`evidence.claim_evidence_link`](../../relations/evidence/claim_evidence_link.md), [`evidence.locator`](../../relations/evidence/locator.md), [`evidence.source_capture`](../../relations/evidence/source_capture.md), [`evidence.verification_run`](../../relations/evidence/verification_run.md), [`orchestration.artifact`](../../relations/orchestration/artifact.md); writes —; calls [`util.current_tenant_id`](../util/current_tenant_id.md).

TypeScript: `Database["retrieval"]["Functions"]["history_claim_authorized"]`.

Defined in: `20260914011100_retrieval_history.sql`.
