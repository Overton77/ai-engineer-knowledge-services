---
id: "fn:evidence.enforce_assessment_producer_not_verifier()"
kind: function
schema: evidence
name: enforce_assessment_producer_not_verifier
domain: evidence
overloads: ["fn:evidence.enforce_assessment_producer_not_verifier()"]
security: invoker
volatility: volatile
executors: [anon, app_reader, authenticated, control_plane, executor_service, pipeline_agent, service_role, verifier_agent]
raises: [producer deployment may not assess its own claim evidence]
touches: { reads: [evidence.claim, evidence.claim_evidence_link, evidence.verification_run, orchestration.attempt], writes: [] }
tokens: [evidence, enforce_assessment_producer_not_verifier, evidence.enforce_assessment_producer_not_verifier]
defined_in: ["20260829194954_normalize_append_only_claim_evidence_assessments.sql"]
workspace_fingerprint: "sha256:21358dd85521af1b5dcd2a27de02214d6d9202cf00158645f05332add0f5fa15"
---
# evidence.enforce_assessment_producer_not_verifier

Domain `evidence`.

## enforce_assessment_producer_not_verifier() → trigger

function, volatile, security invoker, language plpgsql, config `search_path=""`.

No arguments.

Execute: `anon`, `app_reader`, `authenticated`, `control_plane`, `executor_service`, `pipeline_agent`, `service_role`, `verifier_agent`.

Raises (mechanically extracted): `producer deployment may not assess its own claim evidence`.

Touches (best effort): reads [`evidence.claim`](../../relations/evidence/claim.md), [`evidence.claim_evidence_link`](../../relations/evidence/claim_evidence_link.md), [`evidence.verification_run`](../../relations/evidence/verification_run.md), [`orchestration.attempt`](../../relations/orchestration/attempt.md); writes —; calls —.

Defined in: `20260829194954_normalize_append_only_claim_evidence_assessments.sql`.
