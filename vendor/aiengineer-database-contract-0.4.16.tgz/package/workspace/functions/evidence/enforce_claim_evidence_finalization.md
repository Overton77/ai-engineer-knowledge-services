---
id: "fn:evidence.enforce_claim_evidence_finalization()"
kind: function
schema: evidence
name: enforce_claim_evidence_finalization
domain: evidence
overloads: ["fn:evidence.enforce_claim_evidence_finalization()"]
security: invoker
volatility: volatile
executors: [anon, app_reader, authenticated, control_plane, executor_service, pipeline_agent, service_role, verifier_agent]
raises: [claim evidence link permits only one verifier finalization transition, claim evidence links are append-only]
touches: { reads: [], writes: [] }
tokens: [evidence, enforce_claim_evidence_finalization, evidence.enforce_claim_evidence_finalization]
defined_in: ["20260829194743_permit_one_way_claim_evidence_finalization.sql"]
workspace_fingerprint: "sha256:21358dd85521af1b5dcd2a27de02214d6d9202cf00158645f05332add0f5fa15"
---
# evidence.enforce_claim_evidence_finalization

Domain `evidence`.

## enforce_claim_evidence_finalization() → trigger

function, volatile, security invoker, language plpgsql, config `search_path=""`.

No arguments.

Execute: `anon`, `app_reader`, `authenticated`, `control_plane`, `executor_service`, `pipeline_agent`, `service_role`, `verifier_agent`.

Raises (mechanically extracted): `claim evidence link permits only one verifier finalization transition`; `claim evidence links are append-only`.

Defined in: `20260829194743_permit_one_way_claim_evidence_finalization.sql`.
