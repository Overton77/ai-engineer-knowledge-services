---
id: "fn:research.guard_report_projection()"
kind: function
schema: research
name: guard_report_projection
domain: research
overloads: ["fn:research.guard_report_projection()"]
security: definer
volatility: volatile
executors: []
raises: [REPORT_PREDECESSOR_NOT_EARLIER, REPORT_REVISION_SEALED, REPORT_TENANT_MISMATCH]
touches: { reads: [research.report_package_seal, research.report_version], writes: [] }
tokens: [research, guard_report_projection, research.guard_report_projection]
defined_in: ["20260913010000_research_report_packages.sql"]
workspace_fingerprint: "sha256:21358dd85521af1b5dcd2a27de02214d6d9202cf00158645f05332add0f5fa15"
---
# research.guard_report_projection

Domain `research`.

## guard_report_projection() → trigger

function, volatile, security definer, language plpgsql, config `search_path=""`.

No arguments.

Execute: no configured role.

Raises (mechanically extracted): `REPORT_PREDECESSOR_NOT_EARLIER`; `REPORT_REVISION_SEALED`; `REPORT_TENANT_MISMATCH`.

Touches (best effort): reads [`research.report_package_seal`](../../relations/research/report_package_seal.md), [`research.report_version`](../../relations/research/report_version.md); writes —; calls [`util.current_tenant_id`](../util/current_tenant_id.md).

Defined in: `20260913010000_research_report_packages.sql`.
