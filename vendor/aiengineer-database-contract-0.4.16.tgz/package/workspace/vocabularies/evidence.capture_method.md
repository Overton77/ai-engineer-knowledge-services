---
id: "voc:evidence.capture_method"
kind: vocabulary
schema: evidence
name: capture_method
rows: 13
rows_sha256: "sha256:58bd6539cc490c3e087b66ff91ebaec368dc6ddcddcb97944f94db5d4751ae9e"
codes: [api, apify_actor, browser, firecrawl, http, https_acquire, manual, other, repository, whisper_upload, youtube_captions, youtube_transcript, yt_dlp]
workspace_fingerprint: "sha256:21358dd85521af1b5dcd2a27de02214d6d9202cf00158645f05332add0f5fa15"
---
# evidence.capture_method

Reference data snapshot (13 rows, digest `sha256:58bd6539cc490c3e087b66ff91ebaec368dc6ddcddcb97944f94db5d4751ae9e`). Codes are enforced wherever a column has a foreign key to [`evidence.capture_method`](../relations/evidence/capture_method.md).

| code | description |
| --- | --- |
| `api` | api |
| `apify_actor` | apify_actor |
| `browser` | browser |
| `firecrawl` | firecrawl |
| `http` | http |
| `https_acquire` | Trusted exact HTTPS acquisition through an admitted source grant |
| `manual` | manual |
| `other` | other |
| `repository` | repository |
| `whisper_upload` | whisper_upload |
| `youtube_captions` | youtube_captions |
| `youtube_transcript` | youtube_transcript |
| `yt_dlp` | yt_dlp |
