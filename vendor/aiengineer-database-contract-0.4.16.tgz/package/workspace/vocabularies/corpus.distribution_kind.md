---
id: "voc:corpus.distribution_kind"
kind: vocabulary
schema: corpus
name: distribution_kind
rows: 5
rows_sha256: "sha256:7cbea9a9588b2344cb3468870b3922a4460c12b1ef1cccf7bb58108b3553547b"
codes: [hosted_api, open_source, open_weight, proprietary, self_hosted]
workspace_fingerprint: "sha256:21358dd85521af1b5dcd2a27de02214d6d9202cf00158645f05332add0f5fa15"
---
# corpus.distribution_kind

Reference data snapshot (5 rows, digest `sha256:7cbea9a9588b2344cb3468870b3922a4460c12b1ef1cccf7bb58108b3553547b`). Codes are enforced wherever a column has a foreign key to [`corpus.distribution_kind`](../relations/corpus/distribution_kind.md).

| code | description |
| --- | --- |
| `hosted_api` | Hosted API |
| `open_source` | Open source |
| `open_weight` | Open weights |
| `proprietary` | Proprietary |
| `self_hosted` | Self hosted |
