---
id: "voc:evidence.search_provider"
kind: vocabulary
schema: evidence
name: search_provider
rows: 8
rows_sha256: "sha256:6cc9a3ad13539bdc514499f4b87476cb1b079d76a572ab8ef6a4e7a85d75ec89"
codes: [brave, exa, firecrawl, google, manual, other, tavily, youtube]
workspace_fingerprint: "sha256:21358dd85521af1b5dcd2a27de02214d6d9202cf00158645f05332add0f5fa15"
---
# evidence.search_provider

Reference data snapshot (8 rows, digest `sha256:6cc9a3ad13539bdc514499f4b87476cb1b079d76a572ab8ef6a4e7a85d75ec89`). Codes are enforced wherever a column has a foreign key to [`evidence.search_provider`](../relations/evidence/search_provider.md).

| code | description | provider_kind |
| --- | --- | --- |
| `brave` | Brave | search |
| `exa` | Exa | search |
| `firecrawl` | Firecrawl | search |
| `google` | Google | search |
| `manual` | Manual | search |
| `other` | Other | search |
| `tavily` | Tavily | search |
| `youtube` | YouTube | search |
