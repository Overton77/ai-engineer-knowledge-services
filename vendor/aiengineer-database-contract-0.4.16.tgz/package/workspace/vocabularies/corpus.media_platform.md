---
id: "voc:corpus.media_platform"
kind: vocabulary
schema: corpus
name: media_platform
rows: 11
rows_sha256: "sha256:7f93231ecf5fbe63a563618ab8efd68e7a61909af83112079a39e1583e2d500b"
codes: [apple_podcasts, bilibili, conference_platform, linkedin, other, self_hosted, spotify, twitch, vimeo, x, youtube]
workspace_fingerprint: "sha256:21358dd85521af1b5dcd2a27de02214d6d9202cf00158645f05332add0f5fa15"
---
# corpus.media_platform

Reference data snapshot (11 rows, digest `sha256:7f93231ecf5fbe63a563618ab8efd68e7a61909af83112079a39e1583e2d500b`). Codes are enforced wherever a column has a foreign key to [`corpus.media_platform`](../relations/corpus/media_platform.md).

| code | channel_url_template | media_url_template | name | product_entity_id | timecode_param |
| --- | --- | --- | --- | --- | --- |
| `apple_podcasts` | — | — | apple_podcasts | — | — |
| `bilibili` | — | — | bilibili | — | — |
| `conference_platform` | — | — | conference_platform | — | — |
| `linkedin` | — | — | linkedin | — | — |
| `other` | — | — | other | — | — |
| `self_hosted` | — | — | self_hosted | — | — |
| `spotify` | — | — | spotify | — | — |
| `twitch` | — | — | twitch | — | — |
| `vimeo` | — | — | vimeo | — | — |
| `x` | — | — | x | — | — |
| `youtube` | — | — | youtube | — | t |
