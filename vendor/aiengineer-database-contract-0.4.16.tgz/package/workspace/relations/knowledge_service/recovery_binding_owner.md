---
id: "rel:knowledge_service.recovery_binding_owner"
kind: table
schema: knowledge_service
name: recovery_binding_owner
domain: knowledge-service-runtime
aliases: []
tokens: [knowledge_service, recovery_binding_owner, knowledge_service.recovery_binding_owner, tenant_id, original_operation_id, original_intent_id, source_kind, source_id, input_digest, case_id]
summary: null
summary_basis: none
rls: enabled
readers: [executor_service, service_role]
writers: [executor_service, service_role]
typescript: "Database[\"knowledge_service\"][\"Tables\"][\"recovery_binding_owner\"][\"Row\"]"
defined_in: ["20260916020100_recovery_binding_ownership.sql"]
workspace_fingerprint: "sha256:21358dd85521af1b5dcd2a27de02214d6d9202cf00158645f05332add0f5fa15"
---
# knowledge_service.recovery_binding_owner

table in domain `knowledge-service-runtime`.

## Columns

| # | Column | Type | Null | Default | Notes |
| ---: | --- | --- | --- | --- | --- |
| 1 | `tenant_id` | `uuid` | no | — | PK |
| 2 | `original_operation_id` | `uuid` | yes | — | — |
| 3 | `original_intent_id` | `uuid` | yes | — | — |
| 4 | `source_kind` | `text` | no | — | PK; generated: ` CASE     WHEN (original_operation_id IS NOT NULL) THEN 'native'::text     ELSE 'intent'::text END` |
| 5 | `source_id` | `uuid` | no | — | PK; generated: `COALESCE(original_operation_id, original_intent_id)` |
| 6 | `input_digest` | `text` | no | — | PK |
| 7 | `case_id` | `text` | no | — | — |

## Constraints

- PK (tenant_id, source_kind, source_id, input_digest)
- check `recovery_binding_owner_check`: `((original_operation_id IS NULL) <> (original_intent_id IS NULL))`
- check `recovery_binding_owner_input_digest_check`: `(input_digest ~ '^sha256:[a-f0-9]{64}$'::text)`

## Relationships

Outbound: `tenant_id,case_id` → [`knowledge_service.recovery_case`](recovery_case.md)`.tenant_id,case_id`; `tenant_id,original_intent_id` → [`orchestration.operation_intent`](../orchestration/operation_intent.md)`.tenant_id,id`; `tenant_id,original_operation_id` → [`knowledge_service.operation`](operation.md)`.tenant_id,id`.
Inbound: none.

## Indexes

_None._

## Triggers

- `recovery_binding_owner_immutable` → [`util.reject_mutation`](../../functions/util/reject_mutation.md)

## Row-level security

Enabled.
- `recovery_binding_owner_tenant` (ALL) for `executor_service`: `(tenant_id = util.current_tenant_id())`

## Grants

`executor_service`: INSERT, SELECT; `service_role`: INSERT, SELECT. None: `anon`, `app_reader`, `authenticated`, `control_plane`, `pipeline_agent`, `verifier_agent`.

## Read paths

- Direct SELECT: `executor_service`.

## Write path

- Direct DML: `executor_service`.
- Via functions (best effort): [`knowledge_service.check_recovery_original_authority`](../../functions/knowledge_service/check_recovery_original_authority.md).

## TypeScript

insert: `Database["knowledge_service"]["Tables"]["recovery_binding_owner"]["Insert"]`; row: `Database["knowledge_service"]["Tables"]["recovery_binding_owner"]["Row"]`; update: `Database["knowledge_service"]["Tables"]["recovery_binding_owner"]["Update"]`

Defined in: `20260916020100_recovery_binding_ownership.sql`.
