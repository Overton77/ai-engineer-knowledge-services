---
id: "rel:knowledge_service.recovery_original"
kind: table
schema: knowledge_service
name: recovery_original
domain: knowledge-service-runtime
aliases: []
tokens: [knowledge_service, recovery_original, knowledge_service.recovery_original, tenant_id, case_id, original_id, original_operation_id, original_input_digest, used_rounds, attempted_input_digests, attempted_repair_digests, original_intent_id]
summary: null
summary_basis: none
rls: enabled
readers: [executor_service, service_role]
writers: [executor_service, service_role]
typescript: "Database[\"knowledge_service\"][\"Tables\"][\"recovery_original\"][\"Row\"]"
defined_in: ["20260914010700_durable_verification_recovery.sql"]
workspace_fingerprint: "sha256:21358dd85521af1b5dcd2a27de02214d6d9202cf00158645f05332add0f5fa15"
---
# knowledge_service.recovery_original

table in domain `knowledge-service-runtime`.

## Columns

| # | Column | Type | Null | Default | Notes |
| ---: | --- | --- | --- | --- | --- |
| 1 | `tenant_id` | `uuid` | no | — | PK |
| 2 | `case_id` | `text` | no | — | PK |
| 3 | `original_id` | `text` | no | — | PK |
| 4 | `original_operation_id` | `uuid` | yes | — | — |
| 5 | `original_input_digest` | `text` | no | — | — |
| 6 | `used_rounds` | `integer` | no | — | — |
| 7 | `attempted_input_digests` | `jsonb` | no | `'[]'::jsonb` | — |
| 8 | `attempted_repair_digests` | `jsonb` | no | `'[]'::jsonb` | — |
| 9 | `original_intent_id` | `uuid` | yes | — | — |

## Constraints

- PK (tenant_id, case_id, original_id)
- check `recovery_original_check`: `((jsonb_typeof(attempted_input_digests) = 'array'::text) AND (jsonb_typeof(attempted_repair_digests) = 'array'::text))`
- check `recovery_original_one_authority`: `((original_operation_id IS NULL) <> (original_intent_id IS NULL))`
- check `recovery_original_original_input_digest_check`: `(original_input_digest ~ '^sha256:[a-f0-9]{64}$'::text)`
- check `recovery_original_used_rounds_check`: `((used_rounds >= 0) AND (used_rounds <= 2))`

## Relationships

Outbound: `tenant_id,original_intent_id` → [`orchestration.operation_intent`](../orchestration/operation_intent.md)`.tenant_id,id`; `tenant_id,case_id` → [`knowledge_service.recovery_case`](recovery_case.md)`.tenant_id,case_id`; `tenant_id,original_operation_id` → [`knowledge_service.operation`](operation.md)`.tenant_id,id`.
Inbound: [`knowledge_service.recovery_execution`](recovery_execution.md).case_id,original_id.

## Indexes

`recovery_original_intent_binding` where `(original_intent_id IS NOT NULL)`; `recovery_original_native_binding` where `(original_operation_id IS NOT NULL)`

## Triggers

- `recovery_original_authority` → [`knowledge_service.check_recovery_original_authority`](../../functions/knowledge_service/check_recovery_original_authority.md)
- `recovery_original_guard` → [`knowledge_service.guard_recovery_original`](../../functions/knowledge_service/guard_recovery_original.md)
- `recovery_original_no_delete` → [`util.reject_mutation`](../../functions/util/reject_mutation.md)

## Row-level security

Enabled.
- `recovery_original_tenant` (ALL) for `executor_service`: `(tenant_id = util.current_tenant_id())`

## Grants

`executor_service`: INSERT, SELECT, UPDATE; `service_role`: INSERT, SELECT, UPDATE. None: `anon`, `app_reader`, `authenticated`, `control_plane`, `pipeline_agent`, `verifier_agent`.

## Read paths

- Direct SELECT: `executor_service`.

## Write path

- Direct DML: `executor_service`.

## TypeScript

insert: `Database["knowledge_service"]["Tables"]["recovery_original"]["Insert"]`; row: `Database["knowledge_service"]["Tables"]["recovery_original"]["Row"]`; update: `Database["knowledge_service"]["Tables"]["recovery_original"]["Update"]`

Defined in: `20260914010700_durable_verification_recovery.sql`.
